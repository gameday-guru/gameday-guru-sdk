from models import ncaab

print(ncaab.team.efficiency.Efficiency)