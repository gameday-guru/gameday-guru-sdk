from .ncaab import Ncaab

class SportsDataIO:

    ncaab : Ncaab = Ncaab()