from . import sportsdataio

SportsDataIO = sportsdataio.SportsDataIO